javascript
document.addEventListener('DOMContentLoaded', function() {
    const botao = document.querySelector('.botao-grupo');
    
    // Efeito ao clicar no botão
    botao.addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 100);
    });
});
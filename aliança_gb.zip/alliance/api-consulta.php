<?php
// api-consulta.php
// Teste se está funcionando: acesse seu-site.com/api-consulta.php?teste=1

// Headers CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Teste básico
if (isset($_GET['teste'])) {
    die(json_encode([
        'status' => 'OK',
        'message' => 'API PHP está funcionando!',
        'curl_disponivel' => function_exists('curl_init') ? 'SIM' : 'NÃO'
    ]));
}

// Pega parâmetros
$tipo = $_GET['tipo'] ?? '';
$cpf = $_GET['cpf'] ?? '';
$telefone = $_GET['telefone'] ?? '';

// Log de debug
error_log("=== CONSULTA API ===");
error_log("Tipo: $tipo");
error_log("CPF: $cpf");
error_log("Telefone: $telefone");

// Validações
if (empty($tipo)) {
    http_response_code(400);
    die(json_encode(['error' => true, 'message' => 'Parâmetro "tipo" não informado']));
}

$apikey = 'guiznk7';
$url = '';

if ($tipo === 'cpf') {
    $cpf = preg_replace('/\D/', '', $cpf);
    if (strlen($cpf) !== 11) {
        http_response_code(400);
        die(json_encode(['error' => true, 'message' => 'CPF inválido']));
    }
    $url = "https://gl-api.shop/api/cpf?q=$cpf&apikey=guiznk7";
    
} elseif ($tipo === 'telefone') {
    $telefone = preg_replace('/\D/', '', $telefone);
    if (strlen($telefone) < 10 || strlen($telefone) > 11) {
        http_response_code(400);
        die(json_encode(['error' => true, 'message' => 'Telefone inválido']));
    }
    $url = "https://gl-api.shop/api/telefone?telefone=$telefone&apikey=guiznk7";
    
} else {
    http_response_code(400);
    die(json_encode(['error' => true, 'message' => 'Tipo inválido. Use: cpf ou telefone']));
}

error_log("URL requisição: $url");

// Verifica se CURL está disponível
if (!function_exists('curl_init')) {
    http_response_code(500);
    die(json_encode(['error' => true, 'message' => 'CURL não está instalado no servidor']));
}

// Faz requisição
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
$curlErrno = curl_errno($ch);
curl_close($ch);

error_log("HTTP Code: $httpCode");
error_log("CURL Error: $curlError");
error_log("Response: " . substr($response, 0, 200));

// Tratamento de erros
if ($curlErrno !== 0) {
    http_response_code(500);
    die(json_encode([
        'error' => true, 
        'message' => 'Erro CURL: ' . $curlError,
        'errno' => $curlErrno
    ]));
}

if ($httpCode !== 200) {
    http_response_code($httpCode);
    die(json_encode([
        'error' => true,
        'message' => "API retornou código HTTP $httpCode",
        'response' => $response
    ]));
}

// Valida JSON
$json = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(500);
    die(json_encode([
        'error' => true,
        'message' => 'Resposta da API não é um JSON válido',
        'raw_response' => $response
    ]));
}

// Retorna resposta
http_response_code(200);
echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>